</div>
	<div style="clear:both;"></div>
    <!-- Footer -->
    <div id="footer" >
        <div class="container_12">
            <div class="grid_12">
                <!-- You can change the copyright line for your own -->
                <p>&copy; <?php echo date("Y")?>. <a href="#" ><?php  echo APP_NAME;?></a><a style="float:right">Page rendered in <strong>{elapsed_time}</strong> seconds</a></p>
                    <p style="float:right"></p>
            </div>
        </div>
    
    
    </div>
    <!-- End #footer -->
</body></html>	