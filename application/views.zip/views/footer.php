<div class="footer"></div>

</div>

<div id="re-propose"></div>

<div class="bg-popup" id="bg-popup"></div>



<!--- popup--->



<div class="main-popup" id="main-popup" style="display:none;">

<div class="cross"><img src="<?php echo base_url();?>images/cros.png" onclick="close_detail();"/></div>



  <div class="popupNew" id="popupnew"></div>



</div>



<div class="main-popup" id="read-popup" style="display:none;">

<!--<div  class="read_ok cross" ><img src="<?php echo base_url();?>images/cros.png" /></div>-->



  <div class="popupNew" id="popupnew">

  

  

  </div>

  

  



</div>



<!--Fb credit popu-->

<div class="box" id="creadit_popup" style="display:none;">

<div class="cross" id="close_creadit_popup">

<a href="#_"><img src="<?php echo base_url();?>images/cros.png" /></a></div>

	<div class="head">Buy Coins</div>

    <div class="grid_box">

    	<input name="package_opt" type="radio" value="pkg1" class="rdo" id="package_opt1"/>

    	<div class="img"><img src="<?php echo base_url();?>images/images.jpg" width="50" height="50px" /></div>

        <div class="coins_head"><strong>1000</strong> Coins</div>

        <div class="coins_price">$5.00 USD</div>

        

    </div>

    <div class="grid_box">

    	<input name="package_opt" type="radio" value="pkg2" class="rdo" id="package_opt2"/>

    	<div class="img"><img src="<?php echo base_url();?>images/images.jpg" width="50" height="50px" /></div>

        <div class="coins_head"><strong>2500</strong> Coins</div>

        <div class="coins_price">$10.00 USD</div>

        

    </div>

    <div class="grid_box">

    	<input name="package_opt" type="radio" value="pkg3" class="rdo" id="package_opt3"/>

    	<div class="img"><img src="<?php echo base_url();?>images/images.jpg" width="50" height="50px" /></div>

        <div class="coins_head"><strong>7500</strong> Coins</div>

        <div class="coins_price">$20.00 USD</div>

        

    </div>

  <!--  <div class="grid_box">

    	<input name="package_opt" type="radio" value="pkg4" class="rdo" id="package_opt4"/>

    	<div class="img"><img src="<?php echo base_url();?>images/images.jpg" width="50" height="50px" /></div>

        <div class="coins_head"><strong>1500</strong> Coins</div>

        <div class="coins_price">$15.00 USD</div>

        

    </div>

    <div class="grid_box">

    	<input name="package_opt" type="radio" value="pkg5" class="rdo" id="package_opt5"/>

    	<div class="img"><img src="<?php echo base_url();?>images/images.jpg" width="50" height="50px" /></div>

        <div class="coins_head"><strong>2000</strong> Coins</div>

        <div class="coins_price">$20.00 USD</div>

        

    </div>-->

    <input id="package" type="hidden" value="pkg1" name="package">

     <div class="grid_box">

        <div class="buy_btn" id="coinsDiv"><img src="<?php echo base_url();?>images/buy.png" /></div>  	

    </div>



</div>

<!---- end fb credit popup---->
</div>
</body>

</html>